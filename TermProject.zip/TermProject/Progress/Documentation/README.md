# Recoverly – Lost & Found Hub

This project is a simple prototype website for reporting and searching lost items at the community of city colleges of chicago. It includes basic HTML pages styled with CSS.

## Pages
- `index.html`: Home page
- `report.html`: Submit lost item info
- `search.html`: Find lost items
- `contact.html`: Contact details

## Progress Phase
This version includes page structure and form inputs. CSS is minimal and placeholder images are stored in `Assets/images/`.

## Final Version (Coming Soon)
Will include enhanced styling, interactivity, and item search logic.